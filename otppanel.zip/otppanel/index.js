function myFunction() {
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
      document.getElementById("demo").innerHTML = this.responseText;
    }
    xhttp.open("POST", "deerika.djtretailers.com/authentication/guest-user-login" + Math.random());
    var fdata = xhttp.send();
    console.log(fdata);
  }